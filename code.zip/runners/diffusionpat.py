import os
import logging
import time
import glob

import numpy as np
import tqdm
import torch
import torch.utils.data as data

from models.diffusion import Model
from models.ema import EMAHelper
from functions import get_optimizer
from functions.losses import loss_registry
from dataset import data_transform, inverse_data_transform
from functions.ckpt_util import get_ckpt_path
from PAT import PATDataset
from PAT import get_dataset

import torchvision.utils as tvu

def get_beta_schedule(beta_schedule, *, beta_start, beta_end, num_diffusion_timesteps):
    def sigmoid(x):
        return 1 / (np.exp(-x) + 1)

    if beta_schedule == "quad":
        betas = (
            np.linspace(
                beta_start ** 0.5,
                beta_end ** 0.5,
                num_diffusion_timesteps,
                dtype=np.float64,
            )
            ** 2
        )
    elif beta_schedule == "linear":
        betas = np.linspace(
            beta_start, beta_end, num_diffusion_timesteps, dtype=np.float64
        )
    elif beta_schedule == "const":
        betas = beta_end * np.ones(num_diffusion_timesteps, dtype=np.float64)
    elif beta_schedule == "jsd":
        betas = 1.0 / np.linspace(
            num_diffusion_timesteps, 1, num_diffusion_timesteps, dtype=np.float64
        )
    elif beta_schedule == "sigmoid":
        betas = np.linspace(-6, 6, num_diffusion_timesteps)
        betas = sigmoid(betas) * (beta_end - beta_start) + beta_start
    else:
        raise NotImplementedError(beta_schedule)

    assert betas.shape == (num_diffusion_timesteps,)
    return betas


class Diffusion(object):
    def __init__(self, args, config, device=None):
        self.args = args
        self.config = config
        if device is None:
            device = (
                torch.device("cuda")
                if torch.cuda.is_available()
                else torch.device("cpu")
            )
        self.device = device

        # ---- noise schedule ----
        self.model_var_type = config.model.var_type
        betas = get_beta_schedule(
            beta_schedule=config.diffusion.beta_schedule,
            beta_start=config.diffusion.beta_start,
            beta_end=config.diffusion.beta_end,
            num_diffusion_timesteps=config.diffusion.num_diffusion_timesteps,
        )
        betas = self.betas = torch.from_numpy(betas).float().to(self.device)
        self.num_timesteps = betas.shape[0]

        alphas = 1.0 - betas
        alphas_cumprod = alphas.cumprod(dim=0)
        alphas_cumprod_prev = torch.cat(
            [torch.ones(1).to(device), alphas_cumprod[:-1]], dim=0
        )
        posterior_variance = (
            betas * (1.0 - alphas_cumprod_prev) / (1.0 - alphas_cumprod)
        )
        if self.model_var_type == "fixedlarge":
            self.logvar = betas.log()
        elif self.model_var_type == "fixedsmall":
            self.logvar = posterior_variance.clamp(min=1e-20).log()
            
            

    def train(self):
        args, config = self.args, self.config

    # --------------------------------------
    # TensorBoard Logger Setup
    # --------------------------------------
        from torch.utils.tensorboard import SummaryWriter
        if hasattr(self.config, "tb_logger") and self.config.tb_logger is not None:
            print(f"[TB] Logging to: {self.config.tb_logger.logdir}")
            tb_logger = SummaryWriter(self.config.tb_logger.logdir)
        else:
            tb_logger = None
            print("[TB] No TensorBoard logger configured.")

    # --------------------------------------
    # Dataset & DataLoader
    # --------------------------------------
        dataset, test_dataset = get_dataset(args, config)
        train_loader = data.DataLoader(
            dataset,
            batch_size=config.training.batch_size,
            shuffle=True,
            num_workers=config.data.num_workers,
            pin_memory=True,
        )

    # --------------------------------------
    # Model & Optimizer
    # --------------------------------------
        model = Model(config)
        model = model.to(self.device)
        model = torch.nn.DataParallel(model)

        optimizer = get_optimizer(self.config, model.parameters())

    # --------------------------------------
    # EMA Setup
    # --------------------------------------
        if self.config.model.ema:
            ema_helper = EMAHelper(mu=self.config.model.ema_rate)
            ema_helper.register(model)
        else:
            ema_helper = None

    
        start_epoch, step = 0, 0

    
        checkpoint_path = os.path.join(args.log_path, "ckpt.pth")
        if args.resume_training and os.path.exists(checkpoint_path):
            print(f"[TRAIN] Found PAT checkpoint at {checkpoint_path}, resuming...")
            states = torch.load(checkpoint_path, map_location="cpu")
            model.load_state_dict(states[0])
            optimizer.load_state_dict(states[1])
            start_epoch = states[2]
            step = states[3]
            if ema_helper and len(states) > 4:
                ema_helper.load_state_dict(states[4])
        # >>> move EMA shadow params to same device as model <<<
                for k, v in ema_helper.shadow.items():
                    ema_helper.shadow[k] = v.to(self.device)

            print(f"[TRAIN] Resumed from epoch={start_epoch}, step={step}")
            
        else:
            
            print("Loading DDIM-pretrained weights from ckpt_pre.pth")

            pre_ckpt_path = "./ckpt_pre.pth"
            pre_state = torch.load(pre_ckpt_path, map_location="cpu")

        
            assert isinstance(pre_state, list) and isinstance(pre_state[0], dict)
            pretrained_dict = pre_state[0]

        
            target_model = model.module if isinstance(model, torch.nn.DataParallel) else model
            model_dict = target_model.state_dict()

        

            compatible_dict = {
                k: v for k, v in pretrained_dict.items()
                if k in model_dict and v.shape == model_dict[k].shape
            }

            print(f"[PRETRAIN] Loading {len(compatible_dict)} matching parameters "
                  f"out of {len(model_dict)} total.")

            model_dict.update(compatible_dict)
            target_model.load_state_dict(model_dict, strict=True)

            start_epoch, step = 0, 0
            print("[TRAIN] Starting PAT training from epoch 0 with DDIM-pretrained weights.")

    # ============================================================
    #  TIMING SETUP
    # ============================================================
        n_epochs = self.config.training.n_epochs
        
        total_train_start = time.time()
        steps_per_epoch = len(train_loader)
        total_steps = step + (n_epochs - start_epoch) * steps_per_epoch

        print(
            f"[TRAIN] Will train for {n_epochs - start_epoch} more epochs "
            f"({total_steps - step} steps remaining)."
        )

    # ==================== main training loop ====================
        for epoch in range(start_epoch, n_epochs):
            epoch_start = time.time()

        # tqdm progress bar for this epoch
            pbar = tqdm.tqdm(
                enumerate(train_loader),
                total=len(train_loader),
                desc=f"Epoch {epoch}",
                leave=False,
            )

            for i, batch in pbar:
                batch_start = time.time()

                x = batch["image"]                      # (B, 1, H, W)
                n = x.size(0)
                model.train()
                step += 1

                x = x.to(self.device)
            
                e = torch.randn_like(x)
                b = self.betas

            
                t = torch.randint(
                    low=0,
                    high=self.num_timesteps,
                    size=(n // 2 + 1,),
                    device=self.device,
                )
                t = torch.cat([t, self.num_timesteps - t - 1], dim=0)[:n]

            
                loss = loss_registry[config.model.type](model, x, t, e, b)

            # logging
                if tb_logger is not None:
                    tb_logger.add_scalar("loss", loss.item(), global_step=step)
                batch_time = time.time() - batch_start

            
                remaining_steps = max(total_steps - step, 0)
                eta_seconds = remaining_steps * batch_time

                logging.info(
                    f"epoch: {epoch}, step: {step}, "
                    f"loss: {loss.item():.6f}, "
                    f"batch_time: {batch_time:.4f}s, "
                    f"ETA: {eta_seconds/60:.2f} min"
                )

                pbar.set_postfix(
                    loss=f"{loss.item():.4f}",
                    bt=f"{batch_time:.3f}s",
                    eta=f"{eta_seconds/60:.1f}m",
                )

            
                optimizer.zero_grad()
                loss.backward()

                try:
                    torch.nn.utils.clip_grad_norm_(
                        model.parameters(), config.optim.grad_clip
                    )
                except Exception:
                    pass
                optimizer.step()

            
                if self.config.model.ema:
                    ema_helper.update(model)

            
                if step % self.config.training.snapshot_freq == 0 or step == 1:
                    states = [
                        model.state_dict(),
                        optimizer.state_dict(),
                        epoch,   # epoch index of this checkpoint
                        step,
                    ]
                    if self.config.model.ema:
                        states.append(ema_helper.state_dict())

                    os.makedirs(self.args.log_path, exist_ok=True)
                    torch.save(states, os.path.join(self.args.log_path, f"ckpt_{step}.pth"))
                    torch.save(states, os.path.join(self.args.log_path, "ckpt.pth"))

        
            epoch_time = time.time() - epoch_start
            print(
                f"[TRAIN] Finished Epoch {epoch} | "
                f"time: {epoch_time:.2f}s ({epoch_time/60:.2f} min)"
            )
            logging.info(
                f"Finished epoch {epoch} in {epoch_time/60:.2f} minutes "
                f"({epoch_time:.2f} seconds)"
            )

    
        total_train_time = time.time() - total_train_start
        print(
            f"[TRAIN] Total training time: "
            f"{total_train_time:.2f}s | "
            f"{total_train_time/60:.2f} min | "
            f"{total_train_time/3600:.2f} hours"
        )
        logging.info(
            f"Total training time: {total_train_time/3600:.2f} hours "
            f"({total_train_time/60:.2f} minutes)"
        )

    
        final_states = [
            model.state_dict(),
            optimizer.state_dict(),
            n_epochs,   # <-- mark that we've completed all epochs
            step,
        ]
        if self.config.model.ema:
            final_states.append(ema_helper.state_dict())

        torch.save(final_states, os.path.join(self.args.log_path, "ckpt_final.pth"))
        torch.save(final_states, os.path.join(self.args.log_path, "ckpt.pth"))
        print("[TRAIN] Final checkpoint saved. Training complete.")





    def sample(self):
        model = Model(self.config)

        if not self.args.use_pretrained:
            # load your own checkpoint
            if getattr(self.config.sampling, "ckpt_id", None) is None:
                states = torch.load(
                    os.path.join(self.args.log_path, "ckpt.pth"),
                    map_location=self.config.device,
                )
            else:
                states = torch.load(
                    os.path.join(
                        self.args.log_path,
                        f"ckpt_{self.config.sampling.ckpt_id}.pth",
                    ),
                    map_location=self.config.device,
                )
            model = model.to(self.device)
            model = torch.nn.DataParallel(model)
            model.load_state_dict(states[0], strict=True)

            if self.config.model.ema:
                ema_helper = EMAHelper(mu=self.config.model.ema_rate)
                ema_helper.register(model)
                ema_helper.load_state_dict(states[-1])
                ema_helper.ema(model)
            else:
                ema_helper = None
        else:
            
            if self.config.data.dataset == "CIFAR10":
                name = "cifar10"
            elif self.config.data.dataset == "LSUN":
                name = f"lsun_{self.config.data.category}"
            else:
                raise ValueError("Unsupported dataset for pretrained model")
            ckpt = get_ckpt_path(f"ema_{name}")
            print("Loading checkpoint {}".format(ckpt))
            model.load_state_dict(torch.load(ckpt, map_location=self.device))
            model.to(self.device)
            model = torch.nn.DataParallel(model)

        model.eval()

        if self.args.fid:
            self.sample_fid(model)
        elif self.args.sequence:
            self.sample_sequence(model)
        else:
            raise NotImplementedError("Sampling procedure not defined (set fid or sequence).")

    def sample_fid(self, model):
        config = self.config
        img_id = len(glob.glob(f"{self.args.image_folder}/*"))
        print(f"starting from image {img_id}")
        total_n_samples = 1000
        n_rounds = (total_n_samples - img_id) // config.sampling.batch_size

        with torch.no_grad():
            for _ in tqdm.tqdm(
                range(n_rounds), desc="Generating image samples for FID evaluation."
            ):
                n = config.sampling.batch_size
                x = torch.randn(
                    n,
                    config.data.channels,
                    config.data.image_size,
                    config.data.image_size,
                    device=self.device,
                )

                x = self.sample_image(x, model)
                x = inverse_data_transform(config, x)

                for i in range(n):
                    tvu.save_image(
                        x[i], os.path.join(self.args.image_folder, f"{img_id}.png")
                    )
                    img_id += 1

    def sample_sequence(self, model):
        config = self.config

        x = torch.randn(
            1,
            config.data.channels,
            config.data.image_size,
            config.data.image_size,
            device=self.device,
        )

        # produce each predicted x0 at each timestep
        with torch.no_grad():
            _, x = self.sample_image(x, model, last=False)

        x = [inverse_data_transform(config, y) for y in x]

        for i in range(len(x)):
            for j in range(x[i].size(0)):
                tvu.save_image(
                    x[i][j], os.path.join(self.args.image_folder, f"{j}_{i}.png")
                )

    def sample_image(self, x, model, last=True):
        try:
            skip = self.args.skip
        except Exception:
            skip = 1

        # DDIM / generalized sampling
        if self.args.sample_type == "generalized":
            if self.args.skip_type == "uniform":
                skip = self.num_timesteps // self.args.timesteps
                seq = range(0, self.num_timesteps, skip)
            elif self.args.skip_type == "quad":
                seq = (
                    np.linspace(
                        0, np.sqrt(self.num_timesteps * 0.8), self.args.timesteps
                    )
                    ** 2
                )
                seq = [int(s) for s in list(seq)]
            else:
                raise NotImplementedError
            from functions.denoising import generalized_steps

            xs = generalized_steps(x, seq, model, self.betas, eta=self.args.eta)
            x = xs

        # DDPM sampling
        elif self.args.sample_type == "ddpm_noisy":
            if self.args.skip_type == "uniform":
                skip = self.num_timesteps // self.args.timesteps
                seq = range(0, self.num_timesteps, skip)
            elif self.args.skip_type == "quad":
                seq = (
                    np.linspace(
                        0, np.sqrt(self.num_timesteps * 0.8), self.args.timesteps
                    )
                    ** 2
                )
                seq = [int(s) for s in list(seq)]
            else:
                raise NotImplementedError
            from functions.denoising import ddpm_steps

            x = ddpm_steps(x, seq, model, self.betas)
        else:
            raise NotImplementedError("Unknown sample_type")

        if last:
            
            x = x[0][-1]
        return x

    def test(self):
        pass
