import torchvision.transforms as T
from torch.utils.data import Dataset
from typing import Tuple, Union
import numpy as np
import os

class PATDataset(Dataset):
    def __init__(
        self,
        dataroot: str,
        img_size: Union[int, Tuple[int, int]] = 256,
        random_flip: bool = True,
        split: str = "train",
    ):
        self.dataroot = dataroot
        self.split = split
        self.random_flip = random_flip

        if isinstance(img_size, int):
            img_size = (img_size, img_size)
        self.img_size = img_size

        # gather all .npy (or .png / .jpg) files
        self.paths = sorted(
            [
                os.path.join(dataroot, f)
                for f in os.listdir(dataroot)
                if f.endswith(".npy")
            ]
        )

        self.to_tensor = T.ToTensor()
        self.resize = T.Resize(self.img_size)
        self.hflip = T.RandomHorizontalFlip(p=0.5)

    def __len__(self):
        return len(self.paths)

    def _minmax(self, x):
        # normalize to [0,1]
        m = x.min()
        M = x.max()
        if (M - m) < 1e-8:
            return x * 0.0
        return (x - m) / (M - m)

    def __getitem__(self, idx):
        path = self.paths[idx]
        arr = np.load(path)  # shape (H,W) or (H,W,C)

        if arr.ndim == 2:
            arr = arr[..., None]

        arr = arr.astype(np.float32)

        img = self.to_tensor(arr)      # (C,H,W) scaled roughly to [0,1]
        img = self._minmax(img)        # force [0,1]
        img = self.resize(img)         # (C,H,W) to desired size
        img = img * 2.0 - 1.0          # → [-1,1] for diffusion model

        if self.random_flip and self.split == "train":
            img = self.hflip(img)

        case_name = os.path.splitext(os.path.basename(path))[0]
        return {"image": img, "case_name": case_name}
        
        
def get_dataset(args, config):
    """
    Simple dataset factory for PAT.
    Returns: (train_dataset, test_dataset)
    """
    train_root = config.data.train_dataroot
    img_size   = config.data.image_size
    random_flip = bool(config.data.random_flip)

    train_dataset = PATDataset(
        dataroot=train_root,
        img_size=img_size,
        random_flip=random_flip,
        split="train",
    )

    
    test_dataset = None
    return train_dataset, test_dataset