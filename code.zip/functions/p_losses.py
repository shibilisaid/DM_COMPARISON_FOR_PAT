import torch
import torch
import math
import time
from medpy import metric
import numpy as np
np.bool = np.bool_





def noise_estimation_loss(model, x_img, t, e, b, keepdim=False):  # Remove x_gt
    """
    Noise prediction loss for unsupervised training.

    Calculates the difference between the predicted noise and the actual noise added to the input image.

    Args:
        model: The diffusion model.
        x_img: The input image.
        t: The timestep.
        e: The actual noise added to the image.
        b: The beta schedule.
        keepdim: Whether to keep the dimensions of the loss.

    Returns:
        The noise prediction loss.
    """
    
    a = (1 - b).cumprod(dim=0).index_select(0, t).view(-1, 1, 1, 1)

    # X_T  (Noisy image at timestep t)
    x = x_img * a.sqrt() + e * (1.0 - a).sqrt()

    
    eps_pred = model(x, t.float())
    
    per_pixel_se = (eps_pred - e).pow(2)

    
    per_sample_mse = per_pixel_se.mean(dim=(1, 2, 3))   

    # final reduction
    return per_sample_mse if keepdim else per_sample_mse.mean()

    


loss_registry = {
    'simple': noise_estimation_loss,
}