import torch
import random
from pat import forwardMatrixFullRingCDMMI
from misc_utils import awgn

# noisy dataset
class AddGaussianNoise():
    ''' Adds some Gaussian Noise ~ N(0, std^2 I) to an image
    '''
    # structure for custom transform follows pytorch source code
    # https://pytorch.org/vision/stable/_modules/torchvision/transforms/transforms.html
    def __init__(self, std=1.):
        self.std = std

    def __call__(self, image):
        ''' Add noise, returns noisy image'''
        noise = self.std * torch.randn_like(image)
        return image + noise
    def __repr__(self):
        return f"{self.__class__.__name__}()"



# Set up PAT
def PAT_forward(images, PAT_config, forward_A=None, add_noise=False, noise=0.0, remove_transducers=False, removed_transducers=None):
    if forward_A == None:
      A, _, _, _ = forwardMatrixFullRingCDMMI(*PAT_config)
      # the data acquisition matrix T is A^t
      T = torch.tensor(A.T, device=images.device).float()

      if remove_transducers:
          # define a reduced T matrix 
          pixels_to_keep = list(range(0, T.shape[0]))
          for td in removed_transducers:
              N_sample = PAT_config[7]
              for pixel in range(td * N_sample, (td + 1)* N_sample):
                  pixels_to_keep.remove(pixel)
          pixels_to_keep = torch.tensor(pixels_to_keep, device=images.device)
          T_red = torch.index_select(T, 0, pixels_to_keep)
          T = T_red

      P, L = [torch.eye(T.shape[0], device=images.device)] * 2

      # apply y = P(L)Tx
      A = torch.matmul(torch.matmul(P, L), T)
    else:
      A = forward_A

    PAT_images = torch.zeros(images.shape[0], A.shape[0], 1, device=images.device)
    for i in range(len(images)):
        PAT_images[i] = torch.matmul(A, images[i].reshape((-1, 1)))
        if add_noise:
          # PAT_images[i] = PAT_images[i] + noise * torch.randn_like(PAT_images[i])
          PAT_images[i] = torch.tensor(awgn(PAT_images[i].numpy()))
    if remove_transducers:
        N_transducer = PAT_config[0]
        N_sample = PAT_config[7]
        PAT_images = PAT_images.reshape(images.shape[0], 1, N_transducer - len(removed_transducers), N_sample)
    else:
        N_transducer = PAT_config[0]
        PAT_images = PAT_images.reshape(images.shape[0], 1, N_transducer, -1)

    if forward_A == None:
      return PAT_images, P, L, T
    return PAT_images
